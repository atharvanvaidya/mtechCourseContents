# entropy


Calculate Shannon Entropy (min bits per byte-character)

original source: https://www.kennethghartman.com/calculate-file-entropy/

Requirements: Python 3.x

Usage: ./entropy.py \<filename\>
