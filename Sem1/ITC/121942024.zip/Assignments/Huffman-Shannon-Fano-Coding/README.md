# Haffman-Shannon-Fano-Coding
That's python script, that can code sequence of symbol in Haffman, Shannon-Fano codes. 
