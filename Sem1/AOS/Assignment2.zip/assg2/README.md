# Open Terminal and execute the following commands
## Compile the JAVA Files
```
javac *.java
```

## Generate stub and Skeleton classes 
```
rmic AdderRemote
```

## Start a Remote Object Registry on the Port (Here 5000)
```
rmiregistry 5000
```

## Open another terminal and Start the Server
```
java Server
```

## In another Terminal start the Client
```
java Client
```
