import java.rmi.*;
import java.rmi.server.*;
public class AdderRemote extends UnicastRemoteObject implements Adder{
	AdderRemote()throws RemoteException{
		super();
	}
	public int add(int x,int y){
		System.out.println("Received: X:"+x+" and Y:"+y);
		System.out.println("Calculating the Result...");
		return x+y;
	}
	public int sub(int x,int y){
		System.out.println("Received: X:"+x+" and Y:"+y);
		System.out.println("Calculating the Result...");
		return x-y;
	}
	public int mul(int x,int y){
		System.out.println("Received: X:"+x+" and Y:"+y);
		System.out.println("Calculating the Result...");
		return x*y;
	}
	public float div(int x,int y){
		System.out.println("Received: X:"+x+" and Y:"+y);
		System.out.println("Calculating the Result...");
		return x/y;
	}
	public int mod(int x,int y){
		System.out.println("Received: X:"+x+" and Y:"+y);
		System.out.println("Calculating the Result...");
		return x%y;
	}
}
