import java.util.Scanner;
import java.rmi.*;
public class Client{
	public static void main(String args[]){
		try{
			System.out.println("Looking Up for rmi://localhost:5000/atharva in RMI Registry...");
			Adder stub=(Adder)Naming.lookup("rmi://localhost:5000/atharva");
			System.out.println("Welcome to the Calculator Program!");
			Scanner sc = new Scanner(System.in);
			int x,y;
			char choice;
			while(true)
			{
				System.out.println("1.Add\n2.Subtract.\n3.Multiply.\n4.Divide.\n5.Modulus.\n6.Exit");
				System.out.println("Enter Your Choice:");
				choice = sc.next().charAt(0);
				switch(choice)
				{
					case '1':
					{
						System.out.print("Enter X:");
						x = sc.nextInt();
						System.out.print("Enter Y:");
						y = sc.nextInt();
						System.out.println("Calling the function add()...");
						int result = stub.add(x,y);
						System.out.println("Receiving the result of add()...");
						System.out.println("Result:"+result);
						break;
					}
					case '2':
					{
						System.out.print("Enter X:");
						x = sc.nextInt();
						System.out.print("Enter Y:");
						y = sc.nextInt();
						System.out.println("Calling the function sub()...");
						int result = stub.sub(x,y);
						System.out.println("Receiving the result of sub()...");
						System.out.println("Result:"+result);
						break;
					}
					case '3':
					{
						System.out.print("Enter X:");
						x = sc.nextInt();
						System.out.print("Enter Y:");
						y = sc.nextInt();
						System.out.println("Calling the function mul()...");
						int result = stub.mul(x,y);
						System.out.println("Receiving the result of mul()...");
						System.out.println("Result:"+result);
						break;
					}
					case '4':
					{
						System.out.print("Enter X:");
						x = sc.nextInt();
						System.out.print("Enter Y:");
						y = sc.nextInt();
						if(y == 0)
						{
							System.out.println("You cannot enter the Second Number as 0");
							break;
						}
						System.out.println("Calling the function div()...");
						float result = stub.div(x,y);
						System.out.println("Receiving the result of div()...");
						System.out.println("Result:"+result);
						break;
					}
					case '5':
					{
						System.out.print("Enter X:");
						x = sc.nextInt();
						System.out.print("Enter Y:");
						y = sc.nextInt();
						if(y == 0)
						{
							System.out.println("You cannot enter the Second Number as 0");
							break;
						}
						System.out.println("Calling the function mod()...");
						int result = stub.mod(x,y);
						System.out.println("Receiving the result of mod()...");
						System.out.println("Result:"+result);
						break;
					}
					case '6':
					{
						System.out.println("Goodbye!");
						System.exit(0);
					}
					default:
					{
						System.out.println("You entered Wrong Choice!");
					}
				}
			}
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}
