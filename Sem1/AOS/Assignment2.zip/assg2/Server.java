import java.rmi.*;
import java.rmi.registry.*;
public class Server{
	public static void main(String args[]){
		try{
			System.out.println("Creating Adder Object...");
			Adder stub = new AdderRemote();
			System.out.println("Rebinding the EndPoint to the Created object...");
			Naming.rebind("rmi://localhost:5000/atharva",stub);
			System.out.println("Waiting for Client to Connect...");
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}
